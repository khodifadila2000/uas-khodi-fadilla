package com.informatika19100066.khodifadila.model

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.informatika19100066.khodifadila.R

class ResponsActionAlaram : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_respons_action_alaram)
    }
}