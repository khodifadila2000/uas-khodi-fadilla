package com.informatika19100066.khodifadila.service

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class SessionPrefences : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_session_prefences)
    }
}